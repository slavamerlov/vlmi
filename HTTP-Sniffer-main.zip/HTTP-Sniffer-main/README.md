## HTTP Sniffer

![Sniffer](https://img.shields.io/badge/Status-Active-brightgreen) ![License](https://img.shields.io/badge/License-MIT-blue)

### 🔍 Overview
A Python-based HTTP sniffer using Scapy to monitor network traffic, capture HTTP requests, and extract potential credentials from unencrypted traffic.

### 🚀 Features
- Captures HTTP requests in real-time.
- Extracts visited URLs.
- Identifies potential credentials based on common keywords.
- Displays captured data in a structured format.

### ⚙️ Installation
```bash
# Clone the repository
git clone git@github.com:FJLdx/http_sniffer.git
cd http_sniffer

# Install dependencies
pip install -r requirements.txt
```

### ▶️ Usage
```bash
sudo python3 http_sniffer.py
```
Ensure you have the appropriate permissions to sniff network traffic.

### 📜 License
This project is licensed under the MIT License - see the LICENSE file for details.

### ⚠️ Disclaimer
This tool is intended for educational and ethical purposes only. Unauthorized use of network sniffing tools can be illegal. Ensure you have permission before analyzing any network traffic.

---
📌 Developed by [FJLdx](https://github.com/FJLdx)

